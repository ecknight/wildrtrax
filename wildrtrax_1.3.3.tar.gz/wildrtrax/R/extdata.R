#' Dataset "tmtt_predictions.csv"
#'
#' This is a lookup table containing model predictions for 'TMTT' abundance entries.
#'
#' @name tmtt_predictions
#'
#' @section tmtt_predictions.csv:
#'
#' This data is used in wt_replace_tmtt().
