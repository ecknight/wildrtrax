## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = '#>'
)

## ----setup, echo=FALSE, include=FALSE, eval=TRUE------------------------------
# Attach package
library(wildrtrax)
library(dplyr)

load("package.RData")

## ----echo=TRUE, eval=TRUE-----------------------------------------------------
# Note that you need to use 'WT_USERNAME' and 'WT_PASSWORD'
Sys.setenv(WT_USERNAME = 'guest', WT_PASSWORD = 'Apple123')


## ----echo=TRUE, eval=TRUE-----------------------------------------------------
# Authenticate
wt_auth()


## ----echo=TRUE, eval=TRUE, wanring=F, message=F-------------------------------
# Download the project summary you have access to
my_projects <- wt_get_download_summary(sensor_id = 'ARU')

head(my_projects)

## ----echo=TRUE, include=TRUE, eval=F, warning = FALSE, message = FALSE--------
# # Download the project report
# my_report <- wt_download_report(project_id = 620, sensor_id = 'ARU', reports = "main", weather_cols = F) %>%
#   tibble::as_tibble()

## ----echo=F, include=F, eval=T, warning = FALSE, message = FALSE--------------
# Download the project report
my_report <- wt_download_report(project_id = 620, sensor_id = 'ARU', reports = "main", weather_cols = F) %>%
  tibble::as_tibble()

## ----eval=T-------------------------------------------------------------------
head(my_report)


## ----echo=T, include=T, eval=FALSE, warning = F, message = F------------------
# # Download all of the published Ecosystem Health ARU data to a single object
# wt_get_download_summary(sensor_id = "ARU") %>%
#   tibble::as_tibble() %>%
#   dplyr::filter(grepl('^Ecosystem Health',project)) %>%
#   dplyr::mutate(data = purrr::map(.x = project_id, .f = ~wt_download_report(project_id = .x, sensor_id = "ARU", weather_cols = F, reports = "main")))
# 

## ----echo=T, include=F, eval=F, warning = F, message = F----------------------
# # Download all of the published Ecosystem Health ARU data to a single object
# wt_get_download_summary(sensor_id = "ARU") %>%
#   tibble::as_tibble() %>%
#   dplyr::filter(grepl('^Ecosystem Health',project)) %>%
#   dplyr::mutate(data = purrr::map(.x = project_id, .f = ~wt_download_report(project_id = .x, sensor_id = "ARU", weather_cols = F, reports = "main")))
# 

## ----echo=T, include=T, eval=F, warning=F, message = FALSE--------------------
# # Download the WildTrax species table
# spp_table <- wt_get_species()

## ----echo=F, include=F, eval=T, warning=F, message = FALSE--------------------
# Download the WildTrax species table
spp_table <- wt_get_species()

## ----eval=T-------------------------------------------------------------------
spp_table |> arrange(species_code)


## ----echo=T, include=T, eval=T, warning=F, message = FALSE--------------------
# As ARU format
my_report

## ----echo=F, include=F, eval=T, warning=F, message = FALSE--------------------
# As point count format
aru_as_pc <- wt_download_report(project_id = 620, sensor_id = 'PC', reports = "main", weather_cols = F)

## ----eval=T-------------------------------------------------------------------
# As point count format
head(aru_as_pc)


## ----echo=T, include=T, eval=F, warning=F, message = FALSE--------------------
# discover <- wt_dd_summary(sensor = "ARU", species = "White-throated Sparrow", boundary = NULL)

## ----echo=F, include=F, eval=F, warning=F, message = FALSE--------------------
# discover <- wt_dd_summary(sensor = "ARU", species = "White-throated Sparrow", boundary = NULL)

## ----eval=T-------------------------------------------------------------------
head(discover)


## ----echo=T, include=T, eval=F, warning=F, message = FALSE--------------------
# # Define a polygon
# my_aoi <- list(
#   c(-113.96068, 56.23817),
#   c(-117.06285, 54.87577),
#   c(-112.88035, 54.90431),
#   c(-113.96068, 56.23817)
# )
# 
# discover <- wt_dd_summary(sensor = "ARU", species = "White-throated Sparrow", boundary = my_aoi)
# 
# head(discover)
# 

## ----echo=T, include=T, eval=F, warning=F, message = FALSE--------------------
# library(sf)
# # Alberta bounding box
# abbox <- read_sf("...shp") |> # Shapefile of Alberta
#   filter(Province == "Alberta") |>
#   st_transform(crs = 4326) |>
#   st_bbox()
# 
# discover <- wt_dd_summary(sensor = "ARU", species = "White-throated Sparrow", boundary = abbox)
# 
# head(discover)
# 

