## ----include = FALSE, echo = F, include = T, warning = F, message = F---------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = '#>'
)

library(wildrtrax)
library(dplyr)

# Set the directory path
load("package.RData")
#save.image("book.RData")


## ----echo=TRUE, include=TRUE, eval=F, warning = F, message = F----------------
# 
# wt_audio_scanner(path = ".", file_type = "wav", extra_cols = T)
# 

## ----echo=TRUE, include=TRUE, eval=T, warning = F, message = F----------------
files %>%
  dplyr::select(-file_path)


## ----echo=TRUE, include=TRUE, eval=T, warning = F, message = F----------------

files %>%
  dplyr::mutate(hour = as.numeric(format(recording_date_time, "%H"))) %>%
  dplyr::filter(julian == 176, 
         hour %in% c(4:8))


## ----echo=TRUE, include=T, eval=F, warning = F, message = F-------------------
# # Use the wt_* tibble to execute the AP on the files
# 
# wt_run_ap(x = my_files, output_dir = paste0(root, 'ap_outputs'), path_to_ap = '/where/you/store/AP')
# 

## ----echo=T, include=T, eval=F, warning=F, message, prompt=T, comment=""------
# # This example is from ABMI's Ecosystem Health Monitoring program
# 
# my_files <- wt_audio_scanner(".../ABMI-986-SE", file_type = "wav", extra_cols = )
# 
# wt_glean_ap(my_files %>%
#                dplyr::mutate(hour = as.numeric(format(recording_date_time, "%H"))) %>%
#                filter(between(julian,110,220),
#                       hour %in% c(0:3,22:23)), input_dir = ".../ap_outputs", purpose = "biotic")
# 

## ----echo=T, include=TRUE, eval=F, warning=F, message=F-----------------------
# if (dir.exists(".")) {
#   signal_file <- wt_audio_scanner(path = ".", file_type = "wav", extra_cols = T)
# } else {
#   'Can\'\t find this directory'
# }
# 
# wt_signal_level(path = signal_file$file_path,
#                      fmin = 0,
#                      fmax = 10000,
#                      threshold = 5,
#                      channel = 'left')
# 

## ----eval = F-----------------------------------------------------------------
# # Run
# s
# # Return a list object, with parameters stored
# str(s)
# 
# # We can view the output:
# s['output']
# # We have eleven detections that exceeded this threshold.
# 

## ----eval=F, message=FALSE, warning=FALSE, include=T--------------------------
# wt_make_aru_tasks(input = files %>% select(-file_path), task_method = "1SPT", task_length = 180)
# 

## ----eval=F, message=FALSE, warning=FALSE, include=T--------------------------
# # Convert Songscope output into WildTrax tags
# wt_songscope_tags(
#   input,
#   output = c("env", "csv"),
#   my_output_file = NULL,
#   species_code,
#   vocalization_type,
#   score_filter,
#   method = c("USPM", "1SPT"),
#   task_length
# )
# 
# # Convert Kaleidoscope output into WildTrax tags
# wt_kaleidoscope_tags(
#   input,
#   output,
#   tz,
#   freq_bump = T) # Add a frequency buffer to the tag, e.g. 20000 kHz
# 

## ----eval=F, message=FALSE, warning=FALSE, include=T--------------------------
# my_files <- wt_audio_scanner(path = '/my/BigGrid/files', file_type = 'all', extra_cols = F)
# 

## ----eval=F, message=FALSE, warning=FALSE, include=T--------------------------
# my_projects <- wt_get_download_summary(sensor_id = 'ARU') %>%
#   tibble::as_tibble() %>%
#   filter(grepl('Big Grids',project)) %>% # Customized as needed
#   mutate(data = purrr::map(.x = project_id, .f = ~wt_download_report(project_id = .x, sensor_id = 'ARU', weather_cols = F, reports = 'main')))

