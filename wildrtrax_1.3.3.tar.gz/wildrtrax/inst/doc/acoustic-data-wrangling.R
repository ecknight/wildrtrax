## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = '#>'
)

load("package.RData")

## ----setup, echo=FALSE, include=FALSE, eval=TRUE------------------------------
# Attach package
library(wildrtrax)
library(dplyr)

## ----warning = F, message = F, eval = T, include = T, echo = T----------------
# Start by getting everything you need
Sys.setenv(WT_USERNAME = 'guest', WT_PASSWORD = 'Apple123')
wt_auth()
my_report <- wt_download_report(project_id = 620, sensor_id = 'ARU', reports = "main", weather_cols = F) |>
  tibble::as_tibble()

## ----tidy-chunk, eval = T, echo = T, warning = F, message = F-----------------
my_tidy_data <- wt_tidy_species(my_report, remove = c("mammal"), zerofill=F)

# Difference in rows
round((nrow(my_tidy_data)/nrow(my_report)),2)

## ----eval = T, echo = T, warning = F, message = F-----------------------------
my_tmtt_data <- wt_replace_tmtt(data = my_tidy_data, calc = "round")


## ----eval = T, echo = T, warning = F, message = F-----------------------------
my_wide_data <- wt_make_wide(data = my_tmtt_data, sound = "all")

head(my_wide_data)


## ----eval = T, echo = T, warning = F, message = F-----------------------------
my_offset_data <- wt_qpad_offsets(data = my_wide_data, species = "all", version = 3, together = TRUE)

head(my_offset_data)


## ----eval = T, echo = T, warning = F, message = F-----------------------------
dat.occu <- wt_format_occupancy(my_report, species="WCSP", siteCovs=NULL)
mod <- unmarked::occu(~ 1 ~ 1, dat.occu)
mod


