## ----setup, include=FALSE-----------------------------------------------------

#bibliography: references.bib
knitr::opts_chunk$set(echo = TRUE)

library(dplyr)
library(ggplot2)
library(gridExtra)

load("classifiers.RData")
#save.image("classifiers.RData")

## ----eval=F, include=T, echo=F, message=F, warning=F--------------------------
# 
# dat <- curl::curl_download('https://raw.githubusercontent.com/ABbiodiversity/wildRtrax-assets/main/ExpertData_PR_Total.csv','ExpertData_PR_Total.csv') |>
#   readr::read_csv() |>
#   dplyr::filter(classifier=="BirdNET", thresh >= 0.1)
# 

## ----Plots, eval=T, include=T, echo=F, message=F, warning=F-------------------
plot.p <- ggplot(dat) +
  geom_line(aes(x=thresh, y=p), size=1.5) +
  xlab("Score threshold") +
  ylab("Precision") +
  xlim(c(0.1, 1)) +
  ylim(c(0, 1)) +
  theme_bw()

plot.r <- ggplot(dat) +
  geom_line(aes(x=thresh, y=r), size=1.5) +
  xlab("Score threshold") +
  ylab("Recall") +
  xlim(c(0.1, 1)) +
  ylim(c(0, 1)) +
  theme_bw()

plot.f <- ggplot(dat) +
  geom_line(aes(x=thresh, y=f), size=1.5) +
  xlab("Score threshold") +
  ylab("F-score") +
  xlim(c(0.1, 1)) +
  ylim(c(0, 1)) +
  theme_bw()

plot.pr <- ggplot(dat) +
  geom_line(aes(x=r, y=p), size=1.5) +
  xlab("Recall") +
  ylab("Precision") +
  xlim(c(0.1, 1)) +
  ylim(c(0, 1)) +
  theme_bw()

gridExtra::grid.arrange(plot.p, plot.r, plot.f, plot.pr, ncol=2,
                        bottom = "Figure 1. Precision, recall, and F-score of BirdNET  per minute of recording\ncompared to expert human listeners")


## ----include=F, message=F, warning=F, echo=F, eval=T--------------------------
library(wildrtrax)

Sys.setenv(WT_USERNAME = 'guest', WT_PASSWORD = 'Apple123')
wt_auth()

data <- wt_download_report(project_id = 1144,
                           sensor_id = "ARU",
                           reports = c("main", "birdnet"), 
                           weather_cols = FALSE)


## ----include=T, eval=F--------------------------------------------------------
# library(wildrtrax)
# 
# Sys.setenv(WT_USERNAME = 'guest', WT_PASSWORD = 'Apple123')
# wt_auth()
# 
# #This line will take a minute to run while it downloads the data
# data <- wt_download_report(project_id = 1144,
#                            sensor_id = "ARU",
#                            reports = c("main", "birdnet"),
#                            weather_cols = FALSE)
# 

## ----message=F, warning=F-----------------------------------------------------

eval <- wt_evaluate_classifier(data,
                              resolution = "task",
                              remove_species = TRUE,
                              thresholds = c(10, 99))

tail(eval, 5)

## ----More plots, message=F, warning=F-----------------------------------------
plot.p.e <- ggplot(eval) +
  geom_line(aes(x=threshold, y=precision), size=1.5) +
  xlab("Score threshold") +
  ylab("Precision") +
  xlim(0,100) +
  ylim(0,1) +
  theme_bw()

plot.r.e <- ggplot(eval) +
  geom_line(aes(x=threshold, y=recall), size=1.5) +
  xlab("Score threshold") +
  ylab("Recall") +
  xlim(0,100) +
  ylim(0,1) +
  theme_bw()

plot.f.e <- ggplot(eval) +
  geom_line(aes(x=threshold, y=fscore), size=1.5) +
  xlab("Score threshold") +
  ylab("F-score") +
  xlim(0,100) +
  ylim(0,1) +
  theme_bw()

plot.pr.e <- ggplot(eval) +
  geom_line(aes(x=recall, y=precision), size=1.5) +
  xlab("Recall") +
  ylab("Precision") +
  xlim(0,1) +
  ylim(0,1) +
  theme_bw()

library(gridExtra)
grid.arrange(plot.p.e, plot.r.e, plot.f.e, plot.pr.e, ncol=2)

## ----message=F, warning=F-----------------------------------------------------

threshold_use <- wt_classifier_threshold(eval) |> 
  print()


## ----message=F, warning=F-----------------------------------------------------

birdnet <- data[[1]]

detections <- birdnet |>
  filter(confidence > threshold_use)

head(detections)


## ----message=F, warning=F-----------------------------------------------------

eval[eval$threshold==threshold_use,]


## ----message=F, warning=F-----------------------------------------------------

new <- wt_additional_species(data, remove_species = TRUE, threshold = 80, resolution="task")

#potential new detections
nrow(new)

table(new$species_code)


## ----message=F, warning=F-----------------------------------------------------

#Evaluate classifier performance
eval_ccsp <- wt_evaluate_classifier(data,
                              resolution = "task",
                              remove_species = TRUE,
                              species = "CCSP",
                              thresholds = c(10, 99))

#Filter the detections to the best threshold
threshold_ccsp <- wt_classifier_threshold(eval_ccsp)

#Look at performance at that threshold
eval_ccsp[eval_ccsp$threshold==threshold_ccsp,]

#Filter to detections
detections_ccsp <- data[[1]] |>
  filter(species_code == "CCSP", 
         confidence > threshold_ccsp)



## ----CCSP plot, include=T, message=F, warning=F-------------------------------
#Calculate detections per second and mean confidence in each recording
rate_ccsp <- detections_ccsp |> 
  group_by(location_id, recording_date_time, recording_length) |>
  summarize(calls = n(),
            confidence = mean(confidence),
            .groups = "keep") |> 
  ungroup() |> 
  mutate(rate = calls/recording_length*60,
  recording_date_time = as.POSIXct(recording_date_time, format = "%Y-%m-%d %H:%M:%S"),
  yday = as.numeric(format(recording_date_time, "%j")),
  hour = as.numeric(format(recording_date_time, "%H")))

#Filter to the sites with most recordings with detections
occupied_ccsp <- rate_ccsp |> 
  group_by(location_id) |> 
  mutate(recordings = n()) |> 
  ungroup() |> 
  dplyr::filter(recordings >= 4)

#Plot call rate by day of year
ggplot(occupied_ccsp) + 
  geom_point(aes(x=yday, y=rate)) +
  geom_smooth(aes(x=yday, y=rate)) +
  xlab("Day of year") +
  ylab("Rate of Clay-coloured sparrow detections per minute") +
  theme_bw()


